package com.bibliotecaSQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaSQLApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaSQLApplication.class, args);
	}

}
